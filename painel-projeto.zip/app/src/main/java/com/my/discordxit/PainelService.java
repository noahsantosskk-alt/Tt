package com.my.discordxit;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PainelService extends Service {
  // Titulo do painel (troque aqui se quiser)
  static final String TITLE = "Uriel Xiter Android 1.108.X";

  interface Toggle { void on(boolean v); }

  WindowManager wm;
  View circle;
  LinearLayout root;
  ImageView icon;
  WindowManager.LayoutParams pp, ip;
  FrameLayout slider;
  View thumb;
  TextView val;
  float ratio = 0f;
  float d;
  final int RED = Color.parseColor("#EE0000");
  final int RED_DIM = Color.parseColor("#B80000");
  final int BG = Color.parseColor("#121212");
  final int BOX = Color.parseColor("#262626");

  public IBinder onBind(Intent i) { return null; }

  int dp(int v) { return (int) (v * d); }

  public void onCreate() {
    super.onCreate();
    d = getResources().getDisplayMetrics().density;
    wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    int type = Build.VERSION.SDK_INT >= 26
        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        : WindowManager.LayoutParams.TYPE_PHONE;

    // ---------- Circulo FOV (tela inteira, sem toque) ----------
    circle = new View(this) {
      protected void onDraw(Canvas c) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(2));
        p.setColor(Color.WHITE);
        float r = dp(30) + dp(170) * ratio;
        c.drawCircle(getWidth() / 2f, getHeight() / 2f, r, p);
      }
    };
    circle.setVisibility(View.GONE);
    WindowManager.LayoutParams cp = new WindowManager.LayoutParams(
        -1, -1, type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT);
    wm.addView(circle, cp);

    // ---------- Painel ----------
    root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(rr(BG, dp(10)));

    // Cabecalho: ▼ minimiza, ✕ fecha, arrastar o titulo move o painel
    LinearLayout head = new LinearLayout(this);
    head.setGravity(Gravity.CENTER_VERTICAL);
    head.setPadding(dp(10), dp(8), dp(10), dp(8));
    head.setBackground(topRR(RED, dp(10)));
    TextView min = txt("▼", 14, Color.WHITE);
    min.setPadding(dp(4), dp(2), dp(10), dp(2));
    min.setOnClickListener(v -> minimizar());
    TextView title = txt(TITLE, 15, Color.WHITE);
    title.setGravity(Gravity.CENTER);
    TextView close = txt("✕", 16, Color.WHITE);
    close.setPadding(dp(10), dp(2), dp(4), dp(2));
    close.setOnClickListener(v -> stopSelf());
    head.addView(min);
    head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
    head.addView(close);
    root.addView(head, new LinearLayout.LayoutParams(-1, -2));

    // Abas
    final String[] nomes = { "Aimbot", "Esp", "Misc", "Info" };
    final LinearLayout[] tabs = new LinearLayout[4];
    final LinearLayout[] pages = new LinearLayout[4];
    LinearLayout tabRow = new LinearLayout(this);
    tabRow.setPadding(dp(8), dp(8), dp(8), 0);
    for (int i = 0; i < 4; i++) {
      final int k = i;
      tabs[i] = tab(i, nomes[i]);
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
      lp.rightMargin = dp(6);
      tabRow.addView(tabs[i], lp);
      tabs[i].setOnClickListener(v -> select(tabs, pages, k));
    }
    root.addView(tabRow, new LinearLayout.LayoutParams(-1, -2));
    View line = new View(this);
    line.setBackgroundColor(RED);
    root.addView(line, new LinearLayout.LayoutParams(-1, dp(2)));

    // Pagina Aimbot (tudo visual, so o circulo do Fov desenha algo)
    pages[0] = page();
    pages[0].addView(row("Ativar Aimbot", false, null));
    pages[0].addView(row("Aimbot lite", false, null));
    pages[0].addView(row("Injetar headtrick", false, null));
    pages[0].addView(sep());
    pages[0].addView(row("Exibir Circulo do Fov", false,
        on -> circle.setVisibility(on ? View.VISIBLE : View.GONE)));
    pages[0].addView(sliderRow());
    pages[0].addView(dropdownRow());
    pages[0].addView(sep());
    TextView tipo = txt("Tipo de Aimbot", 15, Color.WHITE);
    tipo.setPadding(0, dp(4), 0, dp(2));
    pages[0].addView(tipo);
    pages[0].addView(row("Ao Atirar", false, null));

    // Pagina Esp (placeholder: mande o print dessa aba para ficar igual)
    pages[1] = page();
    pages[1].addView(row("Opção 1", false, null));
    pages[1].addView(row("Opção 2", false, null));
    pages[1].addView(row("Opção 3", false, null));

    // Pagina Misc
    pages[2] = page();
    pages[2].addView(row("Ocultar Em Transmissão", false, null));
    pages[2].addView(row("Esconder Icone", false, null));
    pages[2].addView(sep());
    pages[2].addView(row("Holograma azul", false, null));
    pages[2].addView(row("holograma Verde", false, null));
    pages[2].addView(row("Holograma Roxo", false, null));
    pages[2].addView(row("Holograma amarelo", false, null));
    pages[2].addView(sep());

    // Pagina Info
    pages[3] = page();
    TextView info = txt(TITLE, 15, Color.WHITE);
    info.setPadding(0, dp(8), 0, dp(4));
    pages[3].addView(info);

    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    for (LinearLayout pg : pages) box.addView(pg);
    ScrollView sv = new ScrollView(this);
    sv.setVerticalScrollBarEnabled(false);
    sv.setPadding(dp(10), dp(6), dp(10), dp(6));
    sv.addView(box);
    root.addView(sv, new LinearLayout.LayoutParams(-1, dp(230)));
    select(tabs, pages, 0);

    pp = new WindowManager.LayoutParams(
        dp(310), -2, type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT);
    pp.gravity = Gravity.TOP | Gravity.START;
    pp.x = dp(30);
    pp.y = dp(40);
    title.setOnTouchListener(drag(root, pp, false));
    wm.addView(root, pp);

    // ---------- Icone flutuante (painel minimizado) ----------
    icon = new ImageView(this);
    byte[] bytes = Base64.decode(Logo.B64, Base64.DEFAULT);
    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
    icon.setImageBitmap(bmp);
    icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
    icon.setVisibility(View.GONE);
    ip = new WindowManager.LayoutParams(
        dp(52), dp(52), type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT);
    ip.gravity = Gravity.TOP | Gravity.START;
    ip.x = pp.x;
    ip.y = pp.y;
    icon.setOnTouchListener(drag(icon, ip, true));
    wm.addView(icon, ip);
  }

  // ---------- Arrastar (painel e icone) ----------
  View.OnTouchListener drag(final View target, final WindowManager.LayoutParams lp,
                            final boolean isIcon) {
    return new View.OnTouchListener() {
      int sx, sy;
      float tx, ty;
      boolean moved;
      public boolean onTouch(View v, MotionEvent e) {
        switch (e.getAction()) {
          case MotionEvent.ACTION_DOWN:
            sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false;
            break;
          case MotionEvent.ACTION_MOVE: {
            float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
            if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
            if (moved) {
              lp.x = sx + (int) dx;
              lp.y = sy + (int) dy;
              wm.updateViewLayout(target, lp);
            }
            break;
          }
          case MotionEvent.ACTION_UP:
            // icone: toque curto abre o painel; segurar ~1s fecha tudo
            if (isIcon && !moved) {
              if (e.getEventTime() - e.getDownTime() >= 1000) stopSelf();
              else maximizar();
            }
            break;
        }
        return true;
      }
    };
  }

  void minimizar() {
    ip.x = pp.x;
    ip.y = pp.y;
    wm.updateViewLayout(icon, ip);
    root.setVisibility(View.GONE);
    icon.setVisibility(View.VISIBLE);
  }

  void maximizar() {
    pp.x = ip.x;
    pp.y = ip.y;
    wm.updateViewLayout(root, pp);
    icon.setVisibility(View.GONE);
    root.setVisibility(View.VISIBLE);
  }

  // ---------- Slider "Regular FOV" ----------
  void setRatio(float x) {
    ratio = Math.max(0f, Math.min(1f, x));
    val.setText(String.valueOf(Math.round(ratio * 100)));
    FrameLayout.LayoutParams tp = (FrameLayout.LayoutParams) thumb.getLayoutParams();
    tp.leftMargin = (int) ((slider.getWidth() - tp.width) * ratio);
    thumb.setLayoutParams(tp);
    circle.invalidate();
  }

  LinearLayout sliderRow() {
    LinearLayout r = new LinearLayout(this);
    r.setGravity(Gravity.CENTER_VERTICAL);
    r.setPadding(0, dp(4), 0, dp(4));
    slider = new FrameLayout(this);
    slider.setBackground(rr(BOX, dp(6)));
    thumb = new View(this);
    thumb.setBackgroundColor(RED);
    slider.addView(thumb, new FrameLayout.LayoutParams(dp(10), -1));
    val = txt("0", 15, Color.WHITE);
    val.setGravity(Gravity.CENTER);
    slider.addView(val, new FrameLayout.LayoutParams(-1, -1));
    slider.setOnTouchListener((v, e) -> {
      v.getParent().requestDisallowInterceptTouchEvent(true);
      setRatio(e.getX() / v.getWidth());
      return true;
    });
    slider.post(() -> setRatio(0f));
    r.addView(slider, new LinearLayout.LayoutParams(0, dp(32), 1));
    TextView l = txt("Regular FOV", 15, Color.WHITE);
    l.setPadding(dp(10), 0, 0, 0);
    r.addView(l);
    return r;
  }

  // "Target" (so visual: toque troca o texto)
  LinearLayout dropdownRow() {
    final String[] alvos = { "Cabeça", "Peito", "Corpo" };
    final int[] idx = { 0 };
    LinearLayout r = new LinearLayout(this);
    r.setGravity(Gravity.CENTER_VERTICAL);
    r.setPadding(0, dp(4), 0, dp(4));
    LinearLayout bx = new LinearLayout(this);
    bx.setGravity(Gravity.CENTER_VERTICAL);
    bx.setBackground(rr(BOX, dp(6)));
    final TextView tv = txt(alvos[0], 15, Color.WHITE);
    tv.setPadding(dp(10), 0, 0, 0);
    bx.addView(tv, new LinearLayout.LayoutParams(0, -2, 1));
    TextView arrow = txt("▼", 12, Color.WHITE);
    arrow.setGravity(Gravity.CENTER);
    arrow.setBackgroundColor(RED);
    bx.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(32)));
    bx.setOnClickListener(v -> {
      idx[0] = (idx[0] + 1) % alvos.length;
      tv.setText(alvos[idx[0]]);
    });
    r.addView(bx, new LinearLayout.LayoutParams(0, dp(32), 1));
    TextView l = txt("Target", 15, Color.WHITE);
    l.setPadding(dp(10), 0, 0, 0);
    r.addView(l);
    return r;
  }

  // ---------- Helpers de interface ----------
  GradientDrawable rr(int color, int radius) {
    GradientDrawable g = new GradientDrawable();
    g.setColor(color);
    g.setCornerRadius(radius);
    return g;
  }

  GradientDrawable topRR(int color, int radius) {
    GradientDrawable g = new GradientDrawable();
    g.setColor(color);
    float r = radius;
    g.setCornerRadii(new float[] { r, r, r, r, 0, 0, 0, 0 });
    return g;
  }

  TextView txt(String s, int sp, int color) {
    TextView t = new TextView(this);
    t.setText(s);
    t.setTextSize(sp);
    t.setTextColor(color);
    return t;
  }

  LinearLayout page() {
    LinearLayout l = new LinearLayout(this);
    l.setOrientation(LinearLayout.VERTICAL);
    return l;
  }

  View sep() {
    View v = new View(this);
    v.setBackgroundColor(RED);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
    lp.topMargin = dp(6);
    lp.bottomMargin = dp(6);
    v.setLayoutParams(lp);
    return v;
  }

  LinearLayout tab(int type, String s) {
    LinearLayout l = new LinearLayout(this);
    l.setGravity(Gravity.CENTER_VERTICAL);
    l.setPadding(dp(7), dp(5), dp(7), dp(5));
    l.setBackground(topRR(RED, dp(8)));
    l.addView(new Icon(type), new LinearLayout.LayoutParams(dp(16), dp(16)));
    TextView t = txt(s, 14, Color.WHITE);
    t.setPadding(dp(4), 0, 0, 0);
    l.addView(t);
    return l;
  }

  void select(LinearLayout[] tabs, LinearLayout[] pages, int k) {
    for (int j = 0; j < tabs.length; j++) {
      tabs[j].setBackground(topRR(j == k ? RED : RED_DIM, dp(8)));
      pages[j].setVisibility(j == k ? View.VISIBLE : View.GONE);
    }
  }

  // Checkbox quadrada (so visual; "t" so e usado no circulo do Fov)
  LinearLayout row(String s, boolean on, Toggle t) {
    LinearLayout r = new LinearLayout(this);
    r.setGravity(Gravity.CENTER_VERTICAL);
    r.setPadding(0, dp(5), 0, dp(5));
    final View b = new View(this);
    final boolean[] st = { on };
    b.setBackground(rr(on ? RED : BOX, dp(5)));
    r.addView(b, new LinearLayout.LayoutParams(dp(24), dp(24)));
    TextView tv = txt(s, 15, Color.WHITE);
    tv.setPadding(dp(12), 0, 0, 0);
    r.addView(tv);
    r.setOnClickListener(v -> {
      st[0] = !st[0];
      b.setBackground(rr(st[0] ? RED : BOX, dp(5)));
      if (t != null) t.on(st[0]);
    });
    return r;
  }

  // Icones das abas desenhados em codigo
  class Icon extends View {
    final int type;
    Icon(int t) { super(PainelService.this); type = t; }
    protected void onDraw(Canvas c) {
      Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
      p.setColor(Color.WHITE);
      p.setStyle(Paint.Style.STROKE);
      p.setStrokeWidth(dp(2));
      p.setStrokeCap(Paint.Cap.ROUND);
      float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2;
      float r = Math.min(w, h) / 2f - dp(1);
      if (type == 0) { // mira
        c.drawCircle(cx, cy, r * 0.45f, p);
        c.drawLine(cx, cy - r, cx, cy - r * 0.6f, p);
        c.drawLine(cx, cy + r, cx, cy + r * 0.6f, p);
        c.drawLine(cx - r, cy, cx - r * 0.6f, cy, p);
        c.drawLine(cx + r, cy, cx + r * 0.6f, cy, p);
      } else if (type == 1) { // olho
        c.drawOval(new RectF(cx - r, cy - r * 0.55f, cx + r, cy + r * 0.55f), p);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, r * 0.28f, p);
      } else if (type == 2) { // engrenagem
        c.drawCircle(cx, cy, r * 0.5f, p);
        for (int k = 0; k < 8; k++) {
          double a = k * Math.PI / 4;
          float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
          c.drawLine(cx + ca * r * 0.7f, cy + sa * r * 0.7f,
                     cx + ca * r, cy + sa * r, p);
        }
      } else { // cartao
        c.drawRoundRect(new RectF(cx - r, cy - r * 0.7f, cx + r, cy + r * 0.7f),
            dp(2), dp(2), p);
        c.drawCircle(cx - r * 0.4f, cy - r * 0.1f, r * 0.2f, p);
        c.drawLine(cx + r * 0.05f, cy - r * 0.2f, cx + r * 0.7f, cy - r * 0.2f, p);
        c.drawLine(cx + r * 0.05f, cy + r * 0.2f, cx + r * 0.7f, cy + r * 0.2f, p);
      }
    }
  }

  public void onDestroy() {
    super.onDestroy();
    try { wm.removeView(root); } catch (Exception e) {}
    try { wm.removeView(icon); } catch (Exception e) {}
    try { wm.removeView(circle); } catch (Exception e) {}
  }
}
