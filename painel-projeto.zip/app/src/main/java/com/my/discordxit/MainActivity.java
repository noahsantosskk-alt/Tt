package com.my.discordxit;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
  @Override
  protected void onCreate(Bundle b) {
    super.onCreate(b);
    LinearLayout l = new LinearLayout(this);
    l.setOrientation(LinearLayout.VERTICAL);
    l.setGravity(Gravity.CENTER);
    l.setPadding(48, 48, 48, 48);

    Button abrir = new Button(this);
    abrir.setText("Abrir painel");
    abrir.setOnClickListener(v -> {
      if (Settings.canDrawOverlays(this)) {
        startService(new Intent(this, PainelService.class));
        moveTaskToBack(true);
      } else {
        Toast.makeText(this, "Ative 'Sobrepor a outros apps' e toque de novo", Toast.LENGTH_LONG).show();
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName())));
      }
    });

    Button fechar = new Button(this);
    fechar.setText("Fechar painel");
    fechar.setOnClickListener(v -> stopService(new Intent(this, PainelService.class)));

    l.addView(abrir);
    l.addView(fechar);
    setContentView(l);
  }
}
